"use strict";
Vue.createApp({
    data() {
        return {};
    },
    methods: {}
}).mount("#app");

// user悬浮上下图标切换
let userWUnfold = document.querySelector(".user .w");
let userWUp = document.querySelector(".user .w .up");
let userWDown = document.querySelector(".user .w .down");
userWUnfold.onmouseover=function (){
    setTimeout(function (){
        userWDown.style.display="none";
        userWUp.style.display="inline-block";
    },200);
};
userWUnfold.onmouseout=function (){
    setTimeout(function (){
        userWDown.style.display="inline-block";
        userWUp.style.display="none";
    },200);
};

// explore悬浮上下图标切换
let exploreWUnfold = document.querySelector(".explore .w");
let exploreWUp = document.querySelector(".explore .w .up");
let exploreWDown = document.querySelector(".explore .w .down");
exploreWUnfold.onmouseover=function (){
    setTimeout(function (){
        exploreWDown.style.display="none";
        exploreWUp.style.display="inline-block";
    },200);
};
exploreWUnfold.onmouseout=function (){
    setTimeout(function (){
        exploreWDown.style.display="inline-block";
        exploreWUp.style.display="none";
    },200);
};


let navInputWButtonSvg = document.querySelector(".nav .input .w button svg");
let navInputWButton = document.querySelector(".nav .input .w button");
navInputWButton.onmouseover=function() {
    navInputWButtonSvg.style.stroke="#199F81";
};
navInputWButton.onmouseout=function() {
    navInputWButtonSvg.style.stroke="#7f7f7f";
};